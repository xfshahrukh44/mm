<?php

namespace App\Services;

use App\Repositories\ProductRepository;
use Illuminate\Support\Facades\DB;
use App\Models\Product;


class ProductService extends ProductRepository
{
    
}