<?php

namespace App\Services;

use App\Repositories\StockOutRepository;
use Illuminate\Support\Facades\DB;
use App\Models\StockOut;


class StockOutService extends StockOutRepository
{
    
}