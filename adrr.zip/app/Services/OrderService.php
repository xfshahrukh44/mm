<?php

namespace App\Services;

use App\Repositories\OrderRepository;
use Illuminate\Support\Facades\DB;
use App\Models\Order;


class OrderService extends OrderRepository
{
    
}