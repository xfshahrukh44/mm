<?php

namespace App\Services;

use App\Repositories\ExpenseRepository;
use Illuminate\Support\Facades\DB;
use App\Models\Basket;


class ExpenseService extends ExpenseRepository
{
    
}