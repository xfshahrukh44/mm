<?php

namespace App\Services;

use App\Repositories\OrderProductRepository;
use Illuminate\Support\Facades\DB;
use App\Models\OrderProduct;


class OrderProductService extends OrderProductRepository
{
    
}