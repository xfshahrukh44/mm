<?php

namespace App\Services;

use App\Repositories\ReceivingRepository;
use Illuminate\Support\Facades\DB;
use App\Models\Receiving;


class ReceivingService extends ReceivingRepository
{
    
}