<?php

namespace App\Services;

use App\Repositories\MarketRepository;
use Illuminate\Support\Facades\DB;
use App\Models\Basket;


class MarketService extends MarketRepository
{
    
}