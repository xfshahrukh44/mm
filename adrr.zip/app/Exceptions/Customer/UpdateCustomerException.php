<?php

namespace App\Exceptions\Customer;

use Exception;

class UpdateCustomerException extends Exception
{
    //
}
