<?php

namespace App\Exceptions\Customer;

use Exception;

class AllCustomerException extends Exception
{
    //
}
