<?php

namespace App\Exceptions\Customer;

use Exception;

class DeleteCustomerException extends Exception
{
    //
}
