<?php

namespace App\Exceptions\Product;

use Exception;

class DeleteProductException extends Exception
{
    //
}
