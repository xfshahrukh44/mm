<?php

namespace App\Exceptions\Product;

use Exception;

class AllProductException extends Exception
{
    //
}
