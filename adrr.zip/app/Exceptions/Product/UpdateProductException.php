<?php

namespace App\Exceptions\Product;

use Exception;

class UpdateProductException extends Exception
{
    //
}
