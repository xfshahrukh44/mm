<?php

namespace App\Exceptions\Category;

use Exception;

class DeleteCategoryException extends Exception
{
    //
}
