<?php

namespace App\Exceptions\Category;

use Exception;

class UpdateCategoryException extends Exception
{
    //
}
