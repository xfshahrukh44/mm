<?php

namespace App\Exceptions\Market;

use Exception;

class DeleteMarketException extends Exception
{
    //
}
