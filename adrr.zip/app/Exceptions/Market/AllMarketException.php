<?php

namespace App\Exceptions\Market;

use Exception;

class AllMarketException extends Exception
{
    //
}
