<?php

namespace App\Exceptions\InvoiceProduct;

use Exception;

class UpdateInvoiceProductException extends Exception
{
    //
}
