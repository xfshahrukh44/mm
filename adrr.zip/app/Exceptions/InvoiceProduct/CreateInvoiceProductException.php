<?php

namespace App\Exceptions\InvoiceProduct;

use Exception;

class CreateInvoiceProductException extends Exception
{
    //
}
