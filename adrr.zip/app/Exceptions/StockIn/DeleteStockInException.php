<?php

namespace App\Exceptions\StockIn;

use Exception;

class DeleteStockInException extends Exception
{
    //
}
