<?php

namespace App\Exceptions\StockIn;

use Exception;

class UpdateStockInException extends Exception
{
    //
}
