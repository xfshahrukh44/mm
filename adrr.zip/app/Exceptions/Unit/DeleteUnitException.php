<?php

namespace App\Exceptions\Unit;

use Exception;

class DeleteUnitException extends Exception
{
    //
}
