<?php

namespace App\Exceptions\Unit;

use Exception;

class UpdateUnitException extends Exception
{
    //
}
