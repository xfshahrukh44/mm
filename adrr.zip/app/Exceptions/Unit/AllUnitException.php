<?php

namespace App\Exceptions\Unit;

use Exception;

class AllUnitException extends Exception
{
    //
}
