<?php

namespace App\Exceptions\SpecialDiscount;

use Exception;

class AllSpecialDiscountException extends Exception
{
    //
}
