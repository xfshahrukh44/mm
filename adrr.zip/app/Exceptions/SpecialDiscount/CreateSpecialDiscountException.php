<?php

namespace App\Exceptions\SpecialDiscount;

use Exception;

class CreateSpecialDiscountException extends Exception
{
    //
}
