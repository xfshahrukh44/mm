<?php

namespace App\Exceptions\Expense;

use Exception;

class UpdateExpenseException extends Exception
{
    //
}
