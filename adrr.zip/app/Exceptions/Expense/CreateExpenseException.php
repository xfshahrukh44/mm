<?php

namespace App\Exceptions\Expense;

use Exception;

class CreateExpenseException extends Exception
{
    //
}
