<?php

namespace App\Exceptions\StockOut;

use Exception;

class UpdateStockOutException extends Exception
{
    //
}
