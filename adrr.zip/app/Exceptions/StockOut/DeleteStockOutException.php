<?php

namespace App\Exceptions\StockOut;

use Exception;

class DeleteStockOutException extends Exception
{
    //
}
