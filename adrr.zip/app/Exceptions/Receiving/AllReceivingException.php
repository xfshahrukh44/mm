<?php

namespace App\Exceptions\Receiving;

use Exception;

class AllReceivingException extends Exception
{
    //
}
