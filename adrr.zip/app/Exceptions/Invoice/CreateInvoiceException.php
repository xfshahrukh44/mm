<?php

namespace App\Exceptions\Invoice;

use Exception;

class CreateInvoiceException extends Exception
{
    //
}
