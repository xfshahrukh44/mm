<?php

namespace App\Exceptions\Invoice;

use Exception;

class AllInvoiceException extends Exception
{
    //
}
