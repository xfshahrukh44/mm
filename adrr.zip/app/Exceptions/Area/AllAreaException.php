<?php

namespace App\Exceptions\Area;

use Exception;

class AllAreaException extends Exception
{
    //
}
