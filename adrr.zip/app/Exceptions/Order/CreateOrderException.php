<?php

namespace App\Exceptions\Order;

use Exception;

class CreateOrderException extends Exception
{
    //
}
