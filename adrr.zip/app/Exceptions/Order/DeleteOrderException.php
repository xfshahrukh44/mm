<?php

namespace App\Exceptions\Order;

use Exception;

class DeleteOrderException extends Exception
{
    //
}
