<?php

namespace App\Exceptions\Brand;

use Exception;

class UpdateBrandException extends Exception
{
    //
}
