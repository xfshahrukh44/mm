<?php

namespace App\Exceptions\Brand;

use Exception;

class CreateBrandException extends Exception
{
    //
}
