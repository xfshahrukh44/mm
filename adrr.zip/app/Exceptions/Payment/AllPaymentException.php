<?php

namespace App\Exceptions\Payment;

use Exception;

class AllPaymentException extends Exception
{
    //
}
