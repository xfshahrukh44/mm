<?php

namespace App\Exceptions\Payment;

use Exception;

class UpdatePaymentException extends Exception
{
    //
}
