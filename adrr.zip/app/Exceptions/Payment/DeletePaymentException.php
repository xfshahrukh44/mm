<?php

namespace App\Exceptions\Payment;

use Exception;

class DeletePaymentException extends Exception
{
    //
}
