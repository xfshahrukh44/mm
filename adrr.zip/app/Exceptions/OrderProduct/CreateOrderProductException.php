<?php

namespace App\Exceptions\OrderProduct;

use Exception;

class CreateOrderProductException extends Exception
{
    //
}
