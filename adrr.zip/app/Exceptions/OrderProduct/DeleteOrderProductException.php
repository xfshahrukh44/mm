<?php

namespace App\Exceptions\OrderProduct;

use Exception;

class DeleteOrderProductException extends Exception
{
    //
}
