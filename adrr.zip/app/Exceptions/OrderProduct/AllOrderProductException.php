<?php

namespace App\Exceptions\OrderProduct;

use Exception;

class AllOrderProductException extends Exception
{
    //
}
