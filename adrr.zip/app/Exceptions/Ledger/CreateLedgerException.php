<?php

namespace App\Exceptions\Ledger;

use Exception;

class CreateLedgerException extends Exception
{
    //
}
