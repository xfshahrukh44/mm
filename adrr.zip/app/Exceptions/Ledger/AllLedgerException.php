<?php

namespace App\Exceptions\Ledger;

use Exception;

class AllLedgerException extends Exception
{
    //
}
