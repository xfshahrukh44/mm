<?php

namespace App\Exceptions\Ledger;

use Exception;

class UpdateLedgerException extends Exception
{
    //
}
